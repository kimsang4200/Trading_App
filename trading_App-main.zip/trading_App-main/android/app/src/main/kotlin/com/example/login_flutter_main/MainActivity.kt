package com.example.login_flutter_main

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
